---
description: Reconcile git main vs. the ledger — what merged while you were away (read-only)
allowed-tools: Read, Grep, Glob, Edit, Bash(git fetch:*), Bash(git log:*), Bash(git diff:*), Bash(git status:*), Bash(git branch:*), Bash(git show:*)
---
Using the **Agile-Ledger** skill, reconcile `main` against the ledger. Fetch main, list merges since the `Last main sync` cursor in `Sprint.md`, and map each commit to its US via the bracketed or parenthesized ID (case-insensitive). Flag two cases: (1) merged but the ledger does not show it Done → propose marking Done and filling the Increment; (2) merged with no US ID → surface it as off-plan work to back-fill or query. Read-only by default; update the sync cursor and sync log only after the user reviews.
